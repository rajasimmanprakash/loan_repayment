<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LoanRepay extends Model
{
    use HasFactory;
	
	protected $table = 'loan_repay';
	protected $fillable = [
        'repay_amount_perweek',
        'repay_week_count',
        'user_id',
        'loan_application_id',
        'repay_status',
    ];
}
