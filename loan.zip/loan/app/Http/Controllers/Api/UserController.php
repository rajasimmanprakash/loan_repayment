<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\LoanApplication;
use App\Models\LoanRepay;
use Validator;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use Illuminate\Validation\Rule;
//use Illuminate\Contracts\Validation\Rule;
use Illuminate\Support\Facades\DB;

class UserController extends Controller
{
    public function user_registration(Request $request)
    {
		$validator = Validator::make($request->all(), [
         'name' 		=> 'required|string',
         'email' 		=> 'required|string|email|unique:users',
         'password' 	=> 'required',
  		]);
		if ($validator->fails()) {
			return response()->json(['errors' => $validator->errors()]);
		}
		$is_admin = (isset($request->is_admin) && $request->is_admin == 1)?1:0;	
		User::create([
            'name' 		=> $request->name,
            'email' 	=> $request->email,
            'password' 	=> bcrypt($request->password),
			'is_admin' 	=> $is_admin,
        ]);
		return response()->json(['status' => '200', 'success' => 'Registered successfully.']);
    }
	
	public function user_login(Request $request)
    {
		$validator = Validator::make($request->all(), [
         'email' 		=> 'required|string|email',
         'password' 	=> 'required',
  		]);
		
		if ($validator->fails()) {
			return response()->json(['errors' => $validator->errors()]);
		}
		
        $credentials 	= request(['email', 'password']);
		if(!Auth::attempt($credentials))
			return response()->json(['status' => '401', 'error' => 'Invalid credentials.']);
		$user 			= $request->user();
		$tokenResult 	= $user->createToken('Personal Access Token');
        $token 			= $tokenResult->token;
        if (isset($request->remember_me) && $request->remember_me == 1)
            $token->expires_at = Carbon::now()->addWeeks(1);
        $token->save();
		return response()->json([
            'status'		=> '200',
            'user'			=> Auth::user(),
			'access_token' 	=> $tokenResult->accessToken,
            'token_type' 	=> 'Bearer',
            'expires_at'	=> Carbon::parse(
                $tokenResult->token->expires_at
            )->toDateTimeString()
        ]);	
    }
	
	public function loan_application(Request $request)
    {
		$user_id = Auth::id(); 
		$validator = Validator::make($request->all(), [
         'loan_amount' 				=> 'required|integer',
         'loan_term' 				=> 'required|string',		 
         'installment_period' 		=> 'required|integer|min:5',
  		]);
		
		if ($validator->fails()) {
			return response()->json(['errors' => $validator->errors()]);
		}
		if(isset($request->loan_term) && $request->loan_term != 'weakly'){
			$loan_term_err['loan_term'][] = 'Currently we have only weakly plan. Kindly please enter weakly.';
			return response()->json(['errors' => $loan_term_err]);
		}
		$loan_exists = LoanApplication::where(['user_id'=>$user_id])->first();
		if(isset($loan_exists) && !empty($loan_exists)){ 			//Loan application form update
			$loan_apply = LoanApplication::find($loan_exists->id);
			$loan_apply->loan_amount 			= $request->loan_amount;
			$loan_apply->loan_term 				= $request->loan_term;
			$loan_apply->user_id 				= $user_id;
			$loan_apply->installment_period 	= $request->installment_period;
			$loan_apply->save();
			$msg = 'Successfully updated your loan application. Admin will catch you soon.';
		}else{ 														//Loan application form add
			$loan_apply 				= new LoanApplication;
			$loan_apply->loan_amount 	= $request->loan_amount;
			$loan_apply->loan_term 		= $request->loan_term;
			$loan_apply->user_id 		= $user_id;
			$loan_apply->installment_period 	= $request->installment_period;
			$loan_apply->save();
			$msg = 'Successfully added your loan application. Admin will catch you soon.';
		}
		return response()->json(['status' => '200', 'success' => $msg]);
    }
	
	public function user_loan_details(Request $request)
    {
		$user_id = Auth::id();
		$loan = DB::table('users as u')
			->select('u.id as user_id','u.name','u.email','l.id as loan_id','l.loan_amount','l.interest','l.status_updated_date','l.loan_term','l.installment_period','l.is_approved','l.created_at as loan_registered_date','r.repay_status','r.repay_week_count')
			->leftJoin('loan_application as l', 'l.user_id', '=', 'u.id')
			->leftJoin('loan_repay as r', 'r.user_id', '=', 'l.user_id')
			->where('u.id', '=', $user_id)
			->where('l.is_approved', '!=', null)
			->first();
		if(isset($loan) && !empty($loan)){			
			if(isset($loan->is_approved) && $loan->is_approved == 1){
				$interest_amount 		= ($loan->loan_amount*$loan->interest)/100;
				$total_interest_amount 	= $loan->loan_amount + $interest_amount;
				$amount_per_week 		= $total_interest_amount/$loan->installment_period;
				$is_approved_status 	= 'Approved';
				$msg 					= 'Your loan has been Approved. Your loan interest is '.$loan->interest.' and total loan interest amount is '.$total_interest_amount.' rupees. Kindly please pay your loan due amount '.$amount_per_week.' rupees as per week.';
			}else if(isset($loan->is_approved) && $loan->is_approved == 2){
				$is_approved_status 	= 'Rejected';
				$msg 					= 'Sorry! Your loan has been Rejected. For futher information please contact our admin.';
			}else{
				$msg 					= 'Still Your loan has been Pending. Admin will catch you soon.';
				$is_approved_status 	= 'Pending';
			}
			$loan_arr['user_id'] 				= $loan->user_id;
			$loan_arr['name'] 					= $loan->name;
			$loan_arr['email'] 					= $loan->email;
			$loan_arr['loan_id'] 				= $loan->loan_id;
			$loan_arr['loan_amount'] 			= $loan->loan_amount;
			$loan_arr['loan_term'] 				= $loan->loan_term;
			$loan_arr['installment_period'] 	= $loan->installment_period;
			$loan_arr['loan_registered_date'] 	= $loan->loan_registered_date; 
			$loan_arr['loan_status'] 			= $is_approved_status;
			$loan_arr['interest'] 				= (isset($loan->interest) && $loan->interest != null)?$loan->interest:'';
			$loan_arr['status_updated_date'] 	= (isset($loan->status_updated_date) && $loan->status_updated_date != null)?$loan->status_updated_date:'';			
			$loan_arr['repay_week_count'] 		= (isset($loan->repay_week_count) && $loan->repay_week_count != null)?$loan->repay_week_count:0;			
			if(isset($loan->repay_status) && $loan->repay_status == 1){
				$msg 							= "Successfully you have completed to paid your due amount. Thank you.";
				$loan_arr['loan_repay_status'] 	= 'Paid';
			}
			return response()->json(['status' => '200', 'message' => $msg, 'loan_details' => $loan_arr]);			
		}else{
			$msg = 'Please register loan application form.';
			return response()->json(['error' => $msg]);				
		}
		
    }
	
	public function loan_repay(Request $request)
    {
		$user_id = Auth::id(); 
		$validator = Validator::make($request->all(), [
         'loan_repay_amount' 				=> 'required|integer',		 
  		]);
		if ($validator->fails()) {
			return response()->json(['errors' => $validator->errors()]);
		}
		$user_id = Auth::id();
		$loan = DB::table('loan_application as l')
			->select('l.id as loan_id','l.loan_amount','l.interest','l.status_updated_date','l.loan_term','l.installment_period','l.is_approved','l.created_at as loan_registered_date')
			->where('l.user_id', '=', $user_id)
			->where('l.is_approved', '=', 1)
			->first();
		if(isset($loan) && !empty($loan)){
			$interest_amount = ($loan->loan_amount*$loan->interest)/100;
			$total_interest_amount = $loan->loan_amount + $interest_amount;
			$amount_per_week = $total_interest_amount/$loan->installment_period;
			if(isset($request->loan_repay_amount) && $request->loan_repay_amount < $amount_per_week){
				$loan_repay_msg['loan_repay_amount'][] = 'Your loan repay amount is minimum than your due amount. Please make sure your weakly due amount is '.$amount_per_week.' rupees.';
				$err_status = 'errors';					
				return response()->json([$err_status => $loan_repay_msg]);
			}elseif(isset($request->loan_repay_amount) && $request->loan_repay_amount > $amount_per_week){
				$loan_repay_msg['loan_repay_amount'][] = 'Your loan repay amount is maximum than your due amount. Please make sure your weakly due amount is '.$amount_per_week.' rupees.';
				$err_status = 'errors';					
				return response()->json([$err_status => $loan_repay_msg]);
			}elseif(isset($request->loan_repay_amount) && $request->loan_repay_amount == $amount_per_week){
				$loan_repay_exists = LoanRepay::where(['user_id'=>$user_id])->first();
				if(isset($loan_repay_exists) && !empty($loan_repay_exists)){ //update
					$loan_repay = LoanRepay::find($loan_repay_exists->id);				
					if(isset($loan_repay->repay_week_count) && $loan_repay->repay_week_count != $loan->installment_period){
						$loan_repay->repay_week_count 		= $loan_repay->repay_week_count + 1;
						$loan_repay->repay_status 			= (isset($loan->installment_period) && $loan_repay->repay_week_count  == $loan->installment_period)?1:0;
						$loan_repay->save();
					}
				}else{
					$loan_repay 						= new LoanRepay;
					$loan_repay->repay_amount_perweek 	= $request->loan_repay_amount;
					$loan_repay->repay_week_count 		= 1;
					$loan_repay->loan_application_id 	= $loan->loan_id;
					$loan_repay->user_id 				= $user_id;
					$loan_repay->repay_status 			= 0;
					$loan_repay->save();
				}
				$err_status = 'success';
				$remaining_amount = $total_interest_amount - ($request->loan_repay_amount*$loan_repay->repay_week_count);
				if(isset($loan_repay->repay_week_count) && $loan_repay->repay_week_count == $loan->installment_period){
					$loan_repay_msg = 'Successfully you have completed to paid your due amount. Thank you.';
				}else{
					$loan_repay_msg = 'Loan due amount added successfully. Your paid week count '.$loan_repay->repay_week_count.' and remaining due amount is '.$remaining_amount.' rupees.';
				}
				return response()->json(['status' => '200', 'success' => $loan_repay_msg]);	
			}			
		}else{
			return response()->json(['status' => '401', 'error' => 'Sorry! your are not eligible. Please contact our admin.']);
		}
    }
}