<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateLoanRepayTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('loan_repay', function (Blueprint $table) {
            $table->id();
			$table->string('repay_amount_perweek');
			$table->string('repay_week_count');
			$table->bigInteger('user_id');
			$table->bigInteger('loan_application_id');
			$table->tinyInteger('repay_status')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('loan_repay');
    }
}
