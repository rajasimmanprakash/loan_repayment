<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

//User & Admin - Register and Login api
Route::post('/register', 'App\Http\Controllers\Api\UserController@user_registration');    
Route::post('/login', 'App\Http\Controllers\Api\UserController@user_login');  

//User api
Route::group(["prefix"=>'user'], function(){
	Route::group([
      'middleware' => 'auth:api'
    ], function() {
        //Route::get('/user-detail', 'App\Http\Controllers\Api\UserController@user_detail');
        Route::post('/loan-applicationform', 'App\Http\Controllers\Api\UserController@loan_application');
		Route::get('/loan-details', 'App\Http\Controllers\Api\UserController@user_loan_details');
		Route::post('/loan-repay', 'App\Http\Controllers\Api\UserController@loan_repay');
    });
});

//Admin api
Route::group(["prefix"=>'admin'], function(){
	Route::group([
      'middleware' => 'auth:api'
    ], function() { 
        Route::get('/loan-list', 'App\Http\Controllers\Api\LoanController@loan_list');
        Route::post('/loan-approved/{LOAN_ID}', 'App\Http\Controllers\Api\LoanController@loan_approved');
    });
});